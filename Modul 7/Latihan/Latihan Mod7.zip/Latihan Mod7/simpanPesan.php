<?php
session_start();

// Gunakan idPengirim = 0 jika session tidak tersedia
$idPengirim = isset($_SESSION['id']) ? $_SESSION['id'] : 0;

// Ambil data dari form
$idPenerima = $_POST['Penerima'];
$judul = $_POST['judul'];
$TextPesan = $_POST['TextPesan'];
$date = date('Y-m-d'); // Format tanggal sesuai kolom WktPesan di database

// Koneksi ke database menggunakan mysqli
$conn = mysqli_connect("localhost", "root", "", "dbImpal");

// Periksa koneksi database
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Query menggunakan prepared statement agar aman
$sql = "INSERT INTO pesan (idPenerima, idPengirim, Judul, TextPesan, WktPesan) VALUES (?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($conn, $sql);

if ($stmt) {
    // Bind parameter ke query
    mysqli_stmt_bind_param($stmt, "iisss", $idPenerima, $idPengirim, $judul, $TextPesan, $date);

    // Eksekusi query
    if (mysqli_stmt_execute($stmt)) {
        echo "<script>
                alert('Pesan berhasil ditambahkan.');
                window.location.href = 'tampilPesan.php';
              </script>";
        exit();
    } else {
        echo "Pesan gagal ditambahkan: " . mysqli_error($conn);
    }

    // Tutup statement
    mysqli_stmt_close($stmt);
} else {
    echo "Gagal menyiapkan query: " . mysqli_error($conn);
}

// Tutup koneksi
mysqli_close($conn);
?>
