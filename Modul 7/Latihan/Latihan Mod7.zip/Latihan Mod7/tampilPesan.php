<?php
session_start();

// Gunakan idPengirim = 0 jika session tidak tersedia
$idPengirim = isset($_SESSION['id']) ? $_SESSION['id'] : 0;

if ($idPengirim !== null) {
    // Koneksi ke database
    $conn = mysqli_connect("localhost", "root", "", "dbImpal");

    // Periksa koneksi database
    if (!$conn) {
        die("Koneksi gagal: " . mysqli_connect_error());
    }

    // Query untuk menampilkan pesan milik pengirim tertentu
    $sql = "SELECT idPesan, idPenerima, Judul, TextPesan, WktPesan FROM pesan WHERE idPengirim = ?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        // Bind parameter ke query
        mysqli_stmt_bind_param($stmt, "i", $idPengirim);

        // Eksekusi query
        mysqli_stmt_execute($stmt);

        // Ambil hasil query
        $result = mysqli_stmt_get_result($stmt);

        // Tampilkan data pesan
        echo "<h1>Daftar Pesan Anda</h1>";
        echo "<a href='Form_TambahPesan.php'>Tambah Pesan</a><br><br>"; // Tombol Tambah Pesan diarahkan ke Form_TambahPesan.php
        echo "<table border='1'>";
        echo "<tr><th>ID Pesan</th><th>ID Penerima</th><th>Judul</th><th>Pesan</th><th>Tanggal</th><th>Aksi</th></tr>";

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['idPesan']) . "</td>";
            echo "<td>" . htmlspecialchars($row['idPenerima']) . "</td>";
            echo "<td>" . htmlspecialchars($row['Judul']) . "</td>";
            echo "<td>" . htmlspecialchars($row['TextPesan']) . "</td>";
            echo "<td>" . htmlspecialchars($row['WktPesan']) . "</td>";
            echo "<td><form action='hapusPesan.php' method='post' style='display:inline;'>";
            echo "<input type='hidden' name='idPesan' value='" . htmlspecialchars($row['idPesan']) . "'>";
            echo "<input type='submit' value='Hapus' onclick='return confirm(\"Apakah Anda yakin ingin menghapus pesan ini?\");'>";
            echo "</form></td>";
            echo "</tr>";
        }

        echo "</table>";

        // Tutup statement
        mysqli_stmt_close($stmt);
    } else {
        echo "Gagal menyiapkan query: " . mysqli_error($conn);
    }

    // Tutup koneksi
    mysqli_close($conn);
} else {
    echo "Session tidak ditemukan. Harap login terlebih dahulu.";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Lihat Pesan</title>
</head>
<body>
    <!-- Halaman ini otomatis menampilkan pesan milik pengirim berdasarkan session -->
</body>
</html>
