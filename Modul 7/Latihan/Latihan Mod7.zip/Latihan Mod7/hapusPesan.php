<?php
session_start();

// Ambil id pesan dari data yang dipilih (form atau parameter)
$idPesan = isset($_POST['idPesan']) ? $_POST['idPesan'] : null;

if ($idPesan) {
    // Koneksi ke database
    $conn = mysqli_connect("localhost", "root", "", "dbImpal");

    // Periksa koneksi database
    if (!$conn) {
        die("Koneksi gagal: " . mysqli_connect_error());
    }

    // Query untuk menghapus pesan menggunakan prepared statement
    $sql = "DELETE FROM pesan WHERE idPesan = ?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        // Bind parameter ke query
        mysqli_stmt_bind_param($stmt, "i", $idPesan);

        // Eksekusi query
        if (mysqli_stmt_execute($stmt)) {
            echo "Pesan berhasil dihapus.";
        } else {
            echo "Pesan gagal dihapus: " . mysqli_error($conn);
        }

        // Tutup statement
        mysqli_stmt_close($stmt);
    } else {
        echo "Gagal menyiapkan query: " . mysqli_error($conn);
    }

    // Tutup koneksi
    mysqli_close($conn);
} else {
    echo "Data pesan tidak valid.";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hapus Pesan</title>
</head>
<body>
<form action="hapusPesan.php" method="post">
    <!-- Input idPesan untuk memilih data pesan yang akan dihapus -->
</form>
</body>
</html>
