<!DOCTYPE html>
<html>
<head>
    <title>Tambah Pesan</title>
</head>
<body>
<?php 
// Pastikan tag PHP tidak terbuka tanpa kode di dalamnya
?>
<form action="simpanPesan.php" method="post">
    <!-- Memperbaiki komentar HTML agar ditulis dengan benar -->
    <!-- diasumsikan idPengirim = id user login, didapatkan dari session dan idpesan auto_increment dan tanggal adalah tanggal saat ini sehingga tidak perlu input -->
    <input type="text" name="Penerima" placeholder="Penerima">
    <input type="text" name="judul" placeholder="Judul">
    <textarea name="TextPesan" placeholder="Tulis pesan di sini..."></textarea>
    <input type="submit" name="submit" value="Simpan">
</form>
</body>
</html>
